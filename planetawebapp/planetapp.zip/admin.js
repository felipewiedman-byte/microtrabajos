// Admin: site settings (public), encrypted integration keys, moderation API. Used by server.js
'use strict'
const crypto = require('crypto'), fs = require('fs'), path = require('path')

const DEFAULTS = {
  name: 'PLANETA',
  tagline: 'El mundo está pasando.',
  tagline2: 'Descúbrelo ahora.',
  description: 'Descubre lo que está pasando en cualquier parte del mundo: eventos, lugares, planes y noticias en un mapa vivo.',
  logoDark: '', logoLight: '', favicon: '',
  seoTitle: '', seoKeywords: 'red social, mapa, eventos, planes, noticias, lugares, qué hacer, ciudad, en vivo', ogImage: '', googleVerify: '', indexable: true, sitesOn: true, wdEventsOn: true, vectorStreets: true, radioRules: [], radioAuto: true, cspEnforce: false,
  categories: [['eventos', 'Eventos'], ['lugares', 'Lugares'], ['planes', 'Planes'], ['noticias', 'Noticias'], ['deportes', 'Deportes'], ['ciencia', 'Ciencia y tecnología'], ['cotidiano', 'Vida cotidiana'], ['situaciones', 'Situaciones']],
  bizTypes: [['cafe', 'Café'], ['restaurante', 'Restaurante'], ['bar', 'Bar'], ['tienda', 'Tienda'], ['belleza', 'Belleza'], ['servicio', 'Servicio'], ['hotel', 'Hotel'], ['cultura', 'Cultura'], ['deporte', 'Deporte'], ['otro', 'Otro']],
  regions: [['Mundo', 18, -40, 2.5], ['Colombia', 5, -74, 5.5], ['Latinoamérica', -12, -68, 3.2], ['Norteamérica', 42, -100, 3.4], ['Europa', 46, 5, 4], ['África', 3, 20, 3.3], ['Asia', 30, 105, 3.2], ['Oceanía', -25, 140, 3.6]],
  planRadio: { name: 'Emisora', days: 30, perks: ['Tu emisora suena en toda la web mientras la gente navega', 'Pin con tu logo en tu ciudad y en la ficha de la ciudad', 'Aparece en la lista de Radio, por género'] },
  planEvento: { name: 'Promociona tu evento', days: 7, perks: ['Tu pin queda en el mapa todos los días que pagas (no se quita a las 24 horas)', 'Sale suelto y resaltado, nunca agrupado con otros', 'Aparece primero en la lista de publicaciones'] },
  planBiz: { name: 'Negocio destacado', days: 30, perks: ['Pin dorado en el mapa, visible antes que los demás', 'Tus ofertas y publicaciones salen primero', 'Ficha con fotos, horario, WhatsApp y "Cómo llegar"'] },
  legalTerms: '', legalPrivacy: '',
  festivalsOn: true, holidaysOn: false, festivalsCustom: [],
  hereOn: false, tvOn: true, map3dLight: true, map3dLightK: 60, map3dVariety: true, map3dHeightK: 100, map3dStadiums: true, map3dTerrain: false, quakesOn: true, quakeHours: 6,
  sportsOn: false, sportsProvider: 'apifootball', sportsTeams2: [], sportsLeagues: [], sportsLeagues2: [], sportsDailyMax: 90, sportsLiveMin: 10, sportsDetailMin: 5,
  sportsTeams: ['Real Madrid', 'Barcelona', 'Atletico Madrid', 'Manchester City', 'Manchester United', 'Liverpool', 'Arsenal', 'Chelsea', 'Tottenham', 'Bayern Munchen', 'Bayern Munich', 'Borussia Dortmund', 'Paris Saint Germain', 'Juventus', 'Inter', 'AC Milan', 'Napoli', 'Benfica', 'FC Porto', 'Ajax', 'Boca Juniors', 'River Plate', 'Flamengo', 'Palmeiras', 'Atletico Nacional', 'Millonarios', 'America de Cali', 'Junior', 'Independiente Santa Fe', 'Deportivo Cali', 'Independiente Medellin', 'Club America', 'Guadalajara Chivas', 'Cruz Azul', 'Inter Miami', 'Colombia', 'Argentina', 'Brazil', 'Spain', 'France', 'England', 'Germany', 'Portugal', 'Mexico', 'USA'],
  sizes: {}, textColors: {}, weights: {}, postTTLHours: 24,
  dailyOn: false, dailyTitle: 'Muéstranos tu cielo ahora', dailyText: 'Sube una foto del cielo desde donde estás y mira el cielo del mundo hoy.', dailyTZ: 'America/Bogota',
  colors: { accent: '#5cc8b0', bg: '#0a0f1a', surface: '#111b2e', text: '#eef1f4', muted: '#8a94a0', live: '#e5484d', verified: '#6aa9ff', win1: '#10203b', win2: '#0a1428', winLine: '#6fa8ff', winText: '#eef3f8', menuOn1: '#2d7bff', menuOn2: '#1b57d4', pub1: '#5ccfb4', pub2: '#2fa7d6', pubText: '#04201b' },
  texts: {},
  bizPrice: '29.900 COP al mes', radioPrice: '49.900 COP al mes', bizAmount: 29900, radioAmount: 49900, eventAmount: 19900, eventUSD: 5, currency: 'COP', bizUSD: 8, radioUSD: 12, bizContact: '', videoMaxSeconds: 60, imageMaxMB: 8, postsPerHour: 20, bannedWords: '', layout: {}, maintenance: false, maintenanceText: 'Estamos mejorando la web. Vuelve en unos minutos.',
}
// every editable text: key -> default (use {name} for the site name)
const TEXTS = {
  joinTitle: 'Únete a {name}', joinSub: 'Crea tu cuenta para publicar, comentar y guardar.',
  welcomeBack: 'Bienvenido de nuevo', createAccount: 'Crea tu cuenta', authSub: 'Descubre y comparte lo que pasa en el mundo.',
  dropButton: 'Soltar en el planeta', publishButton: 'Publicar en {name}', published: 'Publicado en {name}',
  pinHint: 'Haz clic en el mapa donde está ocurriendo', pinTip: 'Clic derecho en el mapa para publicar ahí',
  whatsHappening: '¿Qué está pasando aquí?', inThisView: 'En esta vista', wall: 'Muro', liveNow: 'En directo ahora',
  nearTitle: 'Explorar cerca', messagesTitle: 'Mensajes', communityTitle: 'Comunidad', communitySub: 'Personas que comparten lo que pasa en el mundo.',
  roomTitle: 'Lo que pasa hoy en {city}', emptyRoom: 'La sala de {city} está en silencio. Escribe el primer mensaje.',
  footer: '{name} · 2026',
}
const INTEGRATIONS = {
  google: { label: 'Google (iniciar sesión con Gmail)', fields: { clientId: 'Client ID', clientSecret: 'Client Secret*' } },
  mercadopago: { label: 'Mercado Pago', fields: { publicKey: 'Public Key', accessToken: 'Access Token*', mode: 'Modo (test o live)' } },
  paypal: { label: 'PayPal', fields: { clientId: 'Client ID', secret: 'Secret*', mode: 'Modo (sandbox o live)' } },
  translate: { label: 'Traducción automática (opcional: sin llave usa un servicio gratuito limitado)', fields: { deeplKey: 'DeepL API Key*', googleKey: 'Google Translate API Key*' } },
  apifootball: { label: 'API-Football (partidos automáticos)', fields: { key: 'API Key*' } },
  sportapi: { label: 'SportAPI (partidos automáticos, alternativa con más consultas)', fields: { key: 'API Key*' } },
  correo: { label: 'Correo (enviar «recuperar contraseña»): Brevo o Resend', fields: { provider: 'Servicio: brevo o resend', key: 'API Key*', from: 'Correo remitente (de tu dominio, ej. no-responder@worbita.com)', fromName: 'Nombre del remitente (ej. Worbita)', siteUrl: 'Dirección de tu web (ej. https://worbita.com)' } },
  twitch: { label: 'Twitch (canales de TV: nombre, logo y si está en vivo). Opcional, gratis en dev.twitch.tv', fields: { clientId: 'Client ID', clientSecret: 'Client Secret*' } },
  youtube: { label: 'YouTube Data API (canales de TV: detecta canal, logo y país de cualquier país). Llave gratis en Google Cloud', fields: { key: 'API Key*' } },
  stripe: { label: 'Stripe', fields: { publishableKey: 'Publishable Key', secretKey: 'Secret Key*', webhookSecret: 'Webhook Secret*' } },
}

function init(db, DATA) {
  db.exec(`CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
           CREATE TABLE IF NOT EXISTS secrets (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at INTEGER NOT NULL);`)
  for (const col of ["role TEXT NOT NULL DEFAULT 'user'", 'suspended INTEGER NOT NULL DEFAULT 0']) { try { db.exec('ALTER TABLE users ADD COLUMN ' + col) } catch {} }
  try { db.exec('ALTER TABLE reports ADD COLUMN resolved INTEGER NOT NULL DEFAULT 0') } catch {}
  // encryption key for integration secrets, created once, readable only by root
  const keyFile = path.join(DATA, 'secret.key')
  if (!fs.existsSync(keyFile)) fs.writeFileSync(keyFile, crypto.randomBytes(32).toString('hex'), { mode: 0o600 })
  const KEY = Buffer.from(fs.readFileSync(keyFile, 'utf8').trim(), 'hex')
  const enc = t => { const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', KEY, iv); const d = Buffer.concat([c.update(t, 'utf8'), c.final()]); return [iv, c.getAuthTag(), d].map(b => b.toString('base64')).join('.') }
  const dec = s => { const [iv, tag, d] = s.split('.').map(b => Buffer.from(b, 'base64')); const c = crypto.createDecipheriv('aes-256-gcm', KEY, iv); c.setAuthTag(tag); return Buffer.concat([c.update(d), c.final()]).toString('utf8') }

  let cache = null
  const settings = () => {
    if (cache) return cache
    const s = JSON.parse(JSON.stringify(DEFAULTS))
    for (const r of db.prepare('SELECT key, value FROM settings').all()) { try { s[r.key] = JSON.parse(r.value) } catch {} }
    s.colors = { ...DEFAULTS.colors, ...(s.colors || {}) }; s.texts = { ...TEXTS, ...(s.texts || {}) }
    return (cache = s)
  }
  const saveSettings = patch => {
    const up = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
    const str = (x, n) => String(x ?? '').trim().slice(0, n), slug = x => str(x, 40).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
    const pairs = v => Array.isArray(v) ? v.filter(r => Array.isArray(r) && str(r[1], 60)).map(r => [slug(r[0]) || slug(r[1]), str(r[1], 60)]).filter((r, i, a) => r[0] && a.findIndex(x => x[0] === r[0]) === i).slice(0, 40) : null
    const fix = {
      categories: pairs, bizTypes: pairs,
      sportsDetailMin: v => Math.min(60, Math.max(2, Math.round(+v) || 5)),
      sportsProvider: v => v === 'sportapi' ? 'sportapi' : 'apifootball',
      regions: v => Array.isArray(v) ? v.filter(r => Array.isArray(r) && str(r[0], 40) && Number.isFinite(+r[1]) && Number.isFinite(+r[2])).map(r => [str(r[0], 40), +r[1], +r[2], Math.min(18, Math.max(2, +r[3] || 4))]).slice(0, 30) : null,
      planRadio: v => v && typeof v === 'object' ? { name: str(v.name, 40) || 'Plan', days: Math.min(366, Math.max(1, Math.round(+v.days) || 30)), perks: (Array.isArray(v.perks) ? v.perks : []).map(x => str(x, 140)).filter(Boolean).slice(0, 8) } : null,
      hereOn: v => !!v, tvOn: v => !!v, map3dLight: v => !!v, map3dLightK: v => Math.max(30, Math.min(100, Math.round(+v) || 60)), map3dVariety: v => !!v, map3dHeightK: v => Math.max(50, Math.min(300, Math.round(+v) || 100)), map3dStadiums: v => !!v, map3dTerrain: v => !!v, quakesOn: v => !!v, quakeHours: v => Math.max(1, Math.min(24, Math.round(+v) || 6)),
      festivalsOn: v => !!v, holidaysOn: v => !!v, festivalsCustom: v => Array.isArray(v) ? v.filter(r => Array.isArray(r) && String(r[0] || '').trim()).map(r => [String(r[0]).slice(0, 80), String(r[1] || '').slice(0, 80), +r[2], +r[3], String(r[4] || '').slice(0, 5), Math.max(1, Math.min(60, Math.round(+r[5]) || 1)), String(r[6] || '').slice(0, 200)]).slice(0, 200) : null, sportsOn: v => !!v, sportsLiveMin: v => Math.max(1, Math.min(60, Math.round(+v) || 10)), sportsDailyMax: v => Math.max(10, Math.min(100000, Math.round(+v) || 90)), sportsTeams: v => Array.isArray(v) ? v.map(x => String(x).trim().slice(0, 60)).filter(Boolean).slice(0, 300) : null,
      sportsLeagues: v => Array.isArray(v) ? [...new Set(v.map(x => Math.round(+x)).filter(x => Number.isFinite(x) && x > 0))].slice(0, 300) : [],
      sportsLeagues2: v => Array.isArray(v) ? [...new Set(v.map(x => Math.round(+x)).filter(x => Number.isFinite(x) && x > 0))].slice(0, 300) : [],
      sportsTeams2: v => Array.isArray(v) ? v.map(x => String(x).trim().slice(0, 60)).filter(Boolean).slice(0, 300) : [], postTTLHours: v => Math.max(0, Math.min(720, Math.round(+v) || 0)), weights: v => v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).filter(([k, n]) => /^\w{1,30}$/.test(k) && [300, 400, 500, 600, 700, 800].includes(+n)).map(([k, n]) => [k, +n])) : null, sizes: v => v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).filter(([k, n]) => /^\w{1,30}$/.test(k) && +n >= 8 && +n <= 80).map(([k, n]) => [k, +n])) : null, textColors: v => v && typeof v === 'object' ? Object.fromEntries(Object.entries(v).filter(([k, c]) => /^\w{1,30}$/.test(k) && /^#[0-9a-f]{6}$/i.test(c))) : null, legalTerms: v => str(v, 20000), dailyTitle: v => str(v, 80), dailyText: v => str(v, 200), dailyOn: v => !!v, dailyTZ: v => { try { new Date().toLocaleDateString('en-CA', { timeZone: str(v, 60) }); return str(v, 60) } catch { return 'America/Bogota' } }, legalPrivacy: v => str(v, 20000), seoTitle: v => str(v, 70), seoKeywords: v => str(v, 300), googleVerify: v => str(v, 100).replace(/[^\w-]/g, ''), indexable: v => !!v, sitesOn: v => !!v, wdEventsOn: v => !!v, vectorStreets: v => !!v, radioAuto: v => !!v, cspEnforce: v => !!v, radioRules: v => Array.isArray(v) ? v.map(r => ({ t: r && r.t === 'equipo' ? 'equipo' : 'liga', q: String(r?.q || '').trim().slice(0, 60), s: Math.max(0, Math.round(+r?.s) || 0) })).filter(r => r.q && r.s).slice(0, 300) : [],
    }
    fix.bannedWords = v => str(String(v ?? '').replace(/[<>]/g, ''), 4000)
    // diseño del celular (editor visual del panel): solo se aceptan opciones conocidas; {} = diseño original
    const LAY = require('./layout-ids.json'), ids = a => a.map(x => x[0]), MENU_IDS = ids(LAY.menu), TAB_IDS = ids(LAY.tabs), DMENU_IDS = ids(LAY.dmenu), DESK_IDS = LAY.desk, HOME_IDS = ids(LAY.home)
    const pick = (x, list) => list.includes(x) ? x : undefined
    fix.colors = v => v && typeof v === 'object' && !Array.isArray(v) ? Object.fromEntries(Object.entries(v).filter(([k, c]) => /^\w{1,20}$/.test(k) && /^#[0-9a-f]{6}$/i.test(c)).slice(0, 40)) : null
    fix.layout = v => {
      if (!v || typeof v !== 'object' || Array.isArray(v)) return {}
      const out = {}, list = (arr, ids, max) => Array.isArray(arr) ? arr.filter(x => x && ids.includes(x.id)).filter((x, i, a) => a.findIndex(y => y.id === x.id) === i).slice(0, max).map(x => ({ id: x.id, label: str(String(x.label ?? '').replace(/[<>]/g, ''), 24), show: x.show !== false })) : null
      if (v.skin && typeof v.skin === 'object' && !Array.isArray(v.skin)) {
        const sk = { n: {}, c: {} }, NUM = { radius: [0, 24], pad: [0, 30], gap: [0, 24], bw: [0, 4], alpha: [30, 100], menuW: [180, 400], itemH: [24, 48], edge: [0, 60], pin: [40, 120] }
        for (const [k, [lo, hi]] of Object.entries(NUM)) { const x = v.skin.n?.[k]; if (x !== undefined && x !== null && x !== '' && Number.isFinite(+x)) sk.n[k] = Math.min(hi, Math.max(lo, Math.round(+x))) }
        for (const k of ['win1', 'win2', 'line', 'text', 'muted', 'box', 'sel', 'selText', 'on1', 'on2', 'pub1', 'pub2', 'pubText', 'strip', 'scroll']) { const c = v.skin.c?.[k]; if (/^#[0-9a-f]{6}$/i.test(c || '')) sk.c[k] = c }
        if (Object.keys(sk.n).length || Object.keys(sk.c).length) out.skin = sk
      }
      const dm = list(v.dmenu, DMENU_IDS, 30); if (dm) out.dmenu = dm
      if (v.desk && typeof v.desk === 'object' && !Array.isArray(v.desk)) {
        const desk = {}, num = (x, lo, hi) => Number.isFinite(+x) ? Math.round(Math.min(hi, Math.max(lo, +x)) * 100) / 100 : undefined
        for (const id of DESK_IDS) { const w = v.desk[id]; if (!w || typeof w !== 'object') continue; const o = {}; for (const [k, lo, hi] of [['l', -5, 100], ['t', 0, 100], ['b', 0, 100], ['w', 4, 100], ['h', 3, 100]]) { const n = num(w[k], lo, hi); if (n !== undefined) o[k] = n } if (Object.keys(o).length) desk[id] = o }
        if (Object.keys(desk).length) out.desk = desk
      }
      const m = list(v.menu, MENU_IDS, 20); if (m) out.menu = m
      const t = list(v.tabs, TAB_IDS, 5); if (t && t.filter(x => x.show).length >= 2) out.tabs = t
      const hm = list(v.home, HOME_IDS, 4); if (hm) out.home = hm.map(({ id, show }) => ({ id, show }))
      if (v.ui && typeof v.ui === 'object') { const u = {}, f = pick(v.ui.fs, ['small', 'normal', 'large']), b = pick(v.ui.btn, ['compact', 'normal', 'large']), g = pick(v.ui.gap, ['compact', 'normal', 'wide']), r = pick(v.ui.radius, ['square', 'normal', 'round']); if (f) u.fs = f; if (b) u.btn = b; if (g) u.gap = g; if (r) u.radius = r; if (Number.isFinite(+v.ui.listW)) u.listW = Math.min(400, Math.max(200, Math.round(+v.ui.listW))); if (Number.isFinite(+v.ui.panelW)) u.panelW = Math.min(520, Math.max(260, Math.round(+v.ui.panelW))); out.ui = u }
      if (v.dd && typeof v.dd === 'object') { const d = {}; for (const k of ['temas', 'ciudad', 'comunidad', 'panel']) if (k in v.dd) d[k] = !!v.dd[k]; out.dd = d }
      return out
    }
    fix.planBiz = fix.planRadio; fix.planEvento = fix.planRadio; fix.eventAmount = v => Math.max(0, Math.round(+v) || 0); fix.eventUSD = v => Math.max(0, Math.round((+v || 0) * 100) / 100)
    for (let [k, v] of Object.entries(patch)) { if (!(k in DEFAULTS)) continue; if (fix[k]) { v = fix[k](v); if (v === null || (Array.isArray(v) && !v.length && !['sportsTeams', 'sportsTeams2', 'sportsLeagues', 'sportsLeagues2'].includes(k))) continue } up.run(k, JSON.stringify(v)) }
    cache = null; return settings()
  }
  const secret = (provider, field) => { const r = db.prepare('SELECT value FROM secrets WHERE key = ?').get(provider + '.' + field); try { return r ? dec(r.value) : '' } catch { return '' } }
  const integrations = () => Object.fromEntries(Object.entries(INTEGRATIONS).map(([p, def]) => [p, { label: def.label, fields: Object.fromEntries(Object.entries(def.fields).map(([f, label]) => {
    const v = secret(p, f), hidden = label.endsWith('*')
    return [f, { label: label.replace('*', ''), secret: hidden, set: !!v, value: hidden ? (v ? '••••••' + v.slice(-4) : '') : v }]
  })) }]))
  const saveIntegration = (provider, values) => {
    const def = INTEGRATIONS[provider]; if (!def) throw Object.assign(new Error('Integración desconocida.'), { code: 404 })
    const up = db.prepare('INSERT INTO secrets (key, value, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at')
    for (const f of Object.keys(def.fields)) { const v = values[f]; if (typeof v !== 'string' || v.startsWith('••••••')) continue; if (v === '') db.prepare('DELETE FROM secrets WHERE key = ?').run(provider + '.' + f); else up.run(provider + '.' + f, enc(v.trim().slice(0, 500)), Date.now()) }
  }
  async function testIntegration(provider) {
    const get = f => secret(provider, f)
    if (provider === 'mercadopago') { const r = await fetch('https://api.mercadopago.com/users/me', { headers: { Authorization: 'Bearer ' + get('accessToken') }, signal: AbortSignal.timeout(10000) }); const d = await r.json().catch(() => ({})); return r.ok ? `Conectado como ${d.nickname || d.email || d.id}` : 'Mercado Pago rechazó el Access Token (' + r.status + ').' }
    if (provider === 'paypal') { const host = get('mode') === 'live' ? 'api-m.paypal.com' : 'api-m.sandbox.paypal.com'; const r = await fetch(`https://${host}/v1/oauth2/token`, { method: 'POST', body: 'grant_type=client_credentials', headers: { Authorization: 'Basic ' + Buffer.from(get('clientId') + ':' + get('secret')).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' }, signal: AbortSignal.timeout(10000) }); return r.ok ? `Conectado a PayPal (${host.includes('sandbox') ? 'sandbox' : 'live'})` : 'PayPal rechazó las credenciales (' + r.status + ').' }
    if (provider === 'twitch') { const r = await fetch('https://id.twitch.tv/oauth2/token?client_id=' + encodeURIComponent(get('clientId')) + '&client_secret=' + encodeURIComponent(get('clientSecret')) + '&grant_type=client_credentials', { method: 'POST', signal: AbortSignal.timeout(10000) }); return r.ok ? 'Conectado a Twitch' : 'Twitch rechazó la llave (' + r.status + ').' }
    if (provider === 'youtube') { const r = await fetch('https://www.googleapis.com/youtube/v3/channels?part=id&forHandle=%40YouTube&key=' + encodeURIComponent(get('key')), { signal: AbortSignal.timeout(10000) }); return r.ok ? 'Conectado a YouTube' : 'YouTube rechazó la llave (' + r.status + ').' }
    if (provider === 'apifootball') { const r = await fetch((process.env.APIFOOTBALL_URL || 'https://v3.football.api-sports.io') + '/status', { headers: { 'x-apisports-key': get('key') }, signal: AbortSignal.timeout(10000) }); const d = await r.json().catch(() => ({})); const acc = d.response; return acc && acc.subscription ? `Conectado: plan ${acc.subscription.plan}, ${acc.requests?.current ?? 0} de ${acc.requests?.limit_day ?? '?'} consultas usadas hoy` : 'API-Football rechazó la llave.' }
    if (provider === 'sportapi') { const r = await fetch((process.env.SPORTAPI_URL || 'https://sportapi.ai/api') + '/leagues', { headers: { 'X-Api-Key': get('key') }, signal: AbortSignal.timeout(10000) }); if (!r.ok) return 'SportAPI rechazó la llave (' + r.status + ').'; const lim = r.headers.get('x-ratelimit-limit'), rem = r.headers.get('x-ratelimit-remaining'); return lim ? `Conectado: te quedan ${rem} de ${lim} consultas hoy` : 'Conectado a SportAPI' }
    if (provider === 'stripe') { const r = await fetch('https://api.stripe.com/v1/balance', { headers: { Authorization: 'Bearer ' + get('secretKey') }, signal: AbortSignal.timeout(10000) }); return r.ok ? 'Conectado a Stripe' : 'Stripe rechazó la Secret Key (' + r.status + ').' }
    if (provider === 'translate') return get('deeplKey') ? 'Se usará DeepL para traducir.' : get('googleKey') ? 'Se usará Google Translate para traducir.' : 'Sin llave: se usa el servicio gratuito MyMemory (limitado por día).'
    if (provider === 'google') return get('clientId') && get('clientSecret') ? 'Llaves guardadas. El inicio de sesión con Google se activa cuando la web tenga dominio con HTTPS.' : 'Faltan el Client ID o el Client Secret.'
    if (provider === 'correo') {
      const pv = (get('provider') || 'brevo').toLowerCase(), k = get('key'); if (!k) return 'Falta la API Key.'
      if (!/^https:\/\//.test(get('siteUrl'))) return 'Falta la dirección de tu web (empieza por https://).'
      if (!get('from').includes('@')) return 'Falta el correo remitente.'
      const r = pv === 'resend' ? await fetch('https://api.resend.com/domains', { headers: { Authorization: 'Bearer ' + k }, signal: AbortSignal.timeout(10000) })
        : await fetch('https://api.brevo.com/v3/account', { headers: { 'api-key': k, accept: 'application/json' }, signal: AbortSignal.timeout(10000) })
      return r.ok ? `Conectado a ${pv === 'resend' ? 'Resend' : 'Brevo'}. Los correos saldrán desde ${get('from')}.` : `${pv === 'resend' ? 'Resend' : 'Brevo'} rechazó la llave (${r.status}).`
    }
    return 'Sin prueba disponible.'
  }
  return { settings, saveSettings, integrations, saveIntegration, testIntegration, secret, TEXTS, DEFAULTS }
}
module.exports = { init }
